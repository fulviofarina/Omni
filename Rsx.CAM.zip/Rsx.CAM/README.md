# Rsx.CAM
* A generic open-source class-library (made on C#) to control CANBERRA Detectors with aid of the GENIE Programming Libraries.
* Requires the USB Dongle-Key from CANBERRA to work.
* The image *ClassDiagram.jpg* should be self-explanatory of the available functions that can be invoked.